import time
import sys
hypo = 0
coté1 = 0
coté2 = 0
carré_hypo = 0
carré_coté1 = 0
carré_coté2 = 0
print("Pythagoria V1.1")
print("AVERTISSEMENT:")
print("Pythagoria est un logiciel dans le but d'automatiser les calculs sur le théorème de Pythagore")
print("En AUCUN cas, Pythagoria à été crée dans le domaine de l'éducation!")
print("En l'utilisant, vous indiquez connaitre les propriétés du théorème de Pythagore.")
print("Durant l'utilisation, des valeurs aproximatifs pourrait être donné! Une valeur avec 10 chiffres ou plus après la décimal n'est plus sur mais aproximative!")
input("Appuyez sur entrer pour continuer...")
def quest(question):
    global entré
    try:
        if question == 1:
            entré = float(input("Veuillez indiquer la valeur de l'hypoténuse..."))
        if question == 2:
            entré = float(input("Veuillez indiquer la valeur du coté 1..."))
        if question == 3:
            entré = float(input("Veuillez indiquer la valeur du coté 2..."))
        if question == 4:
            entré = float(input("Veuillez indiquer la valeur du coté..."))
    except ValueError:
        print("Une valeur invalide à été indiqué! Seul les nombres entiers et décimaux sont pris en charge")
        print("Note: Sur les valeurs décimales, la virgule (,) doit être remplacé par un point(.)")
        print("Le logiciel va s'arrêter")
        time.sleep(15)
        sys.exit()
def base():
    global entré
    try:
        entré = int(input("Que faire? "))
    except ValueError:
        print("Valeur entrée invalide")
        print("Le logiciel va s'arrêter")
        time.sleep(10)
        sys.exit()
def detail(genre):
    global coté1, coté2, hypo, carré_hypo, carré_coté1, carré_coté2
    if genre == 0:
        input("Appuyer sur entrée pour afficher les détails mathématiques...")
        print("Coté 1:",coté1,", Coté 2:",coté2,", Hypoténuse:",hypo)
        print("Valeur au carré; Coté 1:",carré_coté1,", Coté 2:",carré_coté2,", Hypoténuse", carré_hypo)
        input("Appuyer sur entrée pour quitter...")
        sys.exit()
    if genre == 1:
        input("Appuyer sur entrée pour afficher les détails mathématiques...")
        print("Coté 1:",coté1,", Coté 2:",coté2,", Hypoténuse:",hypo)
        print("Valeur au carré; Les deux cotés:",carré_coté1+carré_coté2,", Coté 1:",carré_coté1,", Coté 2:",carré_coté2,", Hypoténuse", carré_hypo)
        input("Appuyer sur entrée pour quitter...")
        sys.exit()
print("Fonctionnalités:")
print("1. Connaitre une longueur")
print("2. Vérifier si un triangle est rectangle")
try:
    entré = int(input("Que faire? "))
except ValueError:
    print("Valeur entrée invalide")
    print("Le logiciel va s'arrêter")
    time.sleep(10)
    sys.exit()
if entré == 1 or entré == 2:
    if entré == 1:
        print("Quel valeur voulez-vous connaitre?")
        print("1. L'hypoténuse")
        print("2. Un coté")
        base()
        if entré == 1:
            quest(2)
            coté1 = entré
            quest(3)
            coté2 = entré
            carré_coté1 = coté1 ** 2
            carré_coté2 = coté2 ** 2
            carré_hypo = carré_coté1 + carré_coté2
            try:
                coté2 = pow(carré_coté2, 0.5)
            except ValueError:
                print("Une erreur est survenue lors du calcul de la racine carré")
                print("La valeur actuel du carrée du deuxième coté est invalide!")
                print("Valeur calculés:")
                print("Coté 1:",coté1,"Coté 2: ? , Hypoténuse:",hypo)
                print("Valeur au carré; Coté 1:",carré_coté1,", Coté 2:",carré_coté2,", Hypotenuse:",carré_hypo)
                input("Appuyez sur entrée pour quitter...")
                sys.exit()
            print("L'hypoténuse mesure", hypo)
            detail(0)
        elif entré == 2:
            quest(1)
            hypo = entré
            quest(4)
            coté1 = entré
            carré_coté1 = coté1 ** 2
            carré_hypo = hypo ** 2
            carré_coté2 = carré_hypo - carré_coté1
            try:
                coté2 = pow(carré_coté2, 0.5)
            except ValueError:
                print("Une erreur est survenue lors du calcul de la racine carré")
                print("La valeur actuel du carrée du deuxième coté est invalide!")
                print("Valeur calculés:")
                print("Coté 1:",coté1,"Coté 2: ? , Hypoténuse:",hypo)
                print("Valeur au carré; Coté 1:",carré_coté1,", Coté 2:",carré_coté2,", Hypotenuse:",carré_hypo)
                input("Appuyez sur entrée pour quitter...")
                sys.exit()
            print("Le deuxième coté mesure", coté2)
            detail(0)
        else:
            print("Fonctionnalité non atribué")
            print("Le logiciel va s'arrêter")
            time.sleep(5)
            sys.exit()
    if entré == 2:
        quest(1)
        hypo = entré
        quest(2)
        coté1 = entré
        quest(3)
        coté2 = entré
        carré_hypo = hypo ** 2
        carré_coté1 = coté1 ** 2
        carré_coté2 = coté2 ** 2
        if carré_hypo == carré_coté1 + carré_coté2:
            print("Ce triangle est rectangle")
            detail(1)
        else:
            print("Ce triangle n'est pas rectangle")
            detail(1)
