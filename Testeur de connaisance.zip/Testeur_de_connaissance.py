from sys import version
from tkinter import messagebox, Entry, Label, Menu, Tk, Button
from tkinter.filedialog import askopenfilename, asksaveasfilename
import os
import random
crash = [0]
def consol(phrase):
    global crash
    print(phrase)
    crash = crash + [phrase]
quest = []
soluc = []
rep = []
rang = 0
suite = True
essaie = 2
try:
    consol("Ceci est la console. La fermer entrainera l'arrêt du programme")
    from tkinter.filedialog import asksaveasfilename
    import time
    import sys
    root = Tk()
    consol("Module importé, fenêtre crée")
    class erreur:
        def error1():
            messagebox.showerror(title="Erreur",message="Cette action n'est pas possible pour le moment! Veuillez entrer au moins une question puis une réponse!")
    class option:
        global titre, aide, desc, bouton1, bouton2, bouton3
        def défintion():
            for c in root.winfo_children():
                c.destroy()
            global titre, aide, desc, bouton1, bouton2, bouton3
            root.title("Testeur de connaisance")
            root.geometry("890x350")
            root.minsize(870, 340)
            root.iconbitmap("evaluation-etoilee.ico")
            titre = Label(root,text="Menu principal", font=("Calibri light", 30))
            aide = Label(root,text="Comment ça marche?", font=("Calibri light", 20))
            desc = Label(root,text="Ce logiciel simple à utiliser vous permettra de réviser en faisait des quizs réalisés par vous ou par des camarades\n Appuyer sur \"Créer un quiz\" pour créer un quiz et laisser-vous guider...\n Si au contraire vous avez déjà un quiz, appuyer sur \"Importer un quiz\" Pour ouvrir un quiz déjà existant!", font=("Calibri", 12))
            bouton1 = Button(root,text="Créer un quiz", command=création.Créer)
            bouton2 = Button(root,text="Importer quiz", command=lecture.main)
            bouton3 = Button(root,text="Non configuré")
            consol("Fenêtre crée")
        def taille():
            global titre, aide, desc, bouton1, bouton2
            width = root.winfo_width() 
            height = root.winfo_height()
            print(width,"x",height)
        def def_menu():
            global titre, aide, desc, bouton1, bouton2
            m = Menu(root)
            menubis = Menu(root)
            action = Menu(root)
            debug = Menu(root)
            m.add_cascade(label ="Logiciel", menu = menubis)
            m.add_cascade(label ="Action", menu = action)
            m.add_cascade(label ="Debug", menu = debug)
            menubis.add_command (label = "Créer quiz", command=création.Créer)
            menubis.add_command (label = "Importer quiz", command=lecture.main)
            menubis.add_command (label="À propos...", command=option.version)
            action.add_command (label = "Fermer", command=option.quit)
            action.add_command (label = "Menu", command=option.reset)
            debug.add_command (label= "Taille", command= option.taille)
            root.config(menu = m, width = 200)
        def quit():
            root.destroy()
            sys.exit()
        def main():
            global titre, aide, desc, bouton1, bouton2
            consol("main")
            option.def_menu()
            titre.config(text="Menu principal")
            aide.config(text="Comment ça marche?")
            desc.config(text="Ce logiciel simple à utiliser vous permettra de réviser en faisait des quizs réalisés par vous ou par des camarades\n Appuyer sur \"Créer un quiz\" pour créer un quiz et laisser-vous guider...\n Si au contraire vous avez déjà un quiz, appuyer sur \"Importer un quiz\" Pour ouvrir un quiz déjà existant!")
            bouton1.config(text="Créer un quiz", command=création.Créer)
            bouton2.config(text="Importer quiz", command=lecture.main)
            titre.pack()
            aide.pack()
            desc.pack()
            bouton1.pack()
            bouton2.pack()
            consol("main prêt")
        def reset():
            option.défintion()
            option.main()
        def null():
            pass
        def quit_save():
            warn = messagebox.askyesno(title="Voulez-vous quitter", message="Rien n'a été sauvegardé! Voulez-vous continuer?")
            if warn == True:
                root.destroy()
                sys.exit()
        def version():
            ver = Tk()
            ver.title("À propos...")
            nom = Label(ver,text="Testeur de connaisance", font=("Calibri light", 30))
            plus = Label(ver, text="Ce logiciel à été crée et distribué gratuitement par Tomservice\nVersion 1.0\nVersion de l'interpréteur Python:\n"+sys.version+"\nLogiciel open-source\nTomservice 2021")
            nom.pack()
            plus.pack()
            ver.mainloop
        def aband():
            message = messagebox.askyesno(title="Quitter",message="Voulez-vous vraiment quitter?")
            if message == True:
                sys.exit()
    class création:
        def Créer():
            global titre, aide, desc, bouton1, bouton2
            consol("créer")
            option.def_menu()
            consol("Menu crée")
            titre.config(text="Création d'un quiz")
            aide.config(text="Quelle type de questionnaire crée?")
            desc.config(text="Explications:\nLes questions simple sont des quizs où l'utilisateur devra entrer la réponse au clavier\nLes QCM sont des questions où l'utlisateur devra répondre A, B, C ou D")
            bouton1.config(text="Questions simples", command= création.question.rafraichir)
            bouton2.config(text="QCM (Choix multiples)", command = création.QCM.question)
            consol("créer prêt")
        class question:
            def rafraichir():
                global entré, phase
                phase = "quest"
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                titre.config(text="Créer question simple")
                aide.config(text="Veuillez entrer une question")
                desc.config(text="Veuillez indiquez dans le champ en dessous votre question\nAppuyer ensuite sur \"Valider question\" pour entrer une réponse")
                entré = Entry(font=("Calibri light", 12))
                bouton1.config(text="Valider question", command = création.question.réponse)
                bouton2.config(text="Terminer", command= erreur.error1)
                bouton3 = Button(text="Quitter", command=option.quit_save)
                titre.pack()
                aide.pack()
                desc.pack()
                entré.pack()
                bouton1.pack()
                bouton2.pack()
                bouton3.pack()
            def réponse ():
                global entré, phase, quest
                actuel = entré.get()
                if actuel == "":
                    messagebox.showerror(title="Impossible de continuer", message="Aucune question n'a été entré!")
                else:
                    phase = "rep"
                    aide.config(text="Veuillez entrer une réponse")
                    desc.config(text="Veuillez indiquez dans le champ en dessous la réponse adéquate a votre question\nAppuyer ensuite sur \"Valider question\" pour entrer une autre question\nSi votre quiz est fini, appuyer sur \"Terminer\"")
                    actuel = entré.get()
                    quest = quest + [actuel]
                    entré.delete("0","end")
                    bouton1.config(command = création.question.question)
                    bouton2.config(command = création.question.save)
            def question():
                global entré, phase, soluc
                phase = "quest"
                actuel = entré.get()
                if actuel == "":
                    messagebox.showerror(title="Impossible de continuer", message="Aucune réponse n'a été entré")
                else:
                    phase = "quest"
                    aide.config(text="Veuillez entrer une question")
                    desc.config(text="Veuillez indiquez dans le champ en dessous votre question\nAppuyer ensuite sur \"Valider question\" pour entrer une réponse")
                    actuel = entré.get()
                    soluc = soluc + [actuel]
                    entré.delete("0","end")
                    bouton1.config(text = "Valider question", command=création.question.réponse)
            def save():
                global entré, quest, soluc
                actuel = entré.get()
                warn = messagebox.askyesno(title="Sauvegarder?", message="Voulez sauvegarder maintenant?")
                save = False
                if warn == True:
                    if actuel != "":
                        if phase == "quest":
                            quest = quest + [actuel]
                        else:
                            soluc = soluc + [actuel]
                        save = True
                    else:
                        if soluc == []:
                            messagebox.showerror(title="Erreur", message="Vous devez entrer au moins une réponse!")
                        else:
                            if phase == "quest":
                                pass
                            else:
                                soluc = soluc + [actuel]
                            save = True
                if save == True:
                    print("boucle save == True")
                    titre.config(text="En attente d'enregistrement")
                    aide.config(text="Via la fenêtre veuillez choisir un répertoire où enregistrer le fichier")
                    desc.config(text="Nous allons sauvegardé un fichier QST qui contiendra vos questions")
                    entré.delete("1", "end")
                    bouton1.config(command=option.null)
                    bouton2.config(command=option.null)
                    fichier = asksaveasfilename(filetypes=[("Fichier question", "*.qst")])
                    try:
                        if os.name == 'nt':
                            if fichier[-4:] == ".qst":
                                with open (fichier,'w') as fichie:
                                    fichie.write("simple\n")
                                    for x in quest:
                                        fichie.write(f'{x}\n')
                            else:
                                with open (fichier+".qst",'w') as fichie:
                                    fichie.write("simple\n")
                                    for x in quest:
                                        fichie.write(f'{x}\n')
                        else:
                            with open (fichier, 'w') as fichie:
                                fichie.write("simple\n")
                                for x in quest():
                                    fichie.write(f'{x}\n')
                    except Exception as error:
                        messagebox.showerror(title="Echec de la sauvegarde", message=f"Le fichier n'a pu être enregistré pour la raison suivante:\n{error}\nLe logiciel prendra fin!")
                        sys.exit()
                    desc.config(text="Il faut maintenant enregistrer un fichier RPS qui contient toutes les réponses de vos question")
                    fichier = asksaveasfilename(filetypes=[("Fichier réponse", "*.rps")])
                    try:
                        if os.name == 'nt':
                            if fichier[-4:] == ".rps":
                                with open (fichier+".rps", 'w') as fichie:
                                    fichie.write("simple\n")
                                    for x in soluc:
                                        fichie.write(f'{x}\n')                            
                            else:
                                with open (fichier+".rps", 'w') as fichie:
                                    fichie.write("simple\n")
                                    for x in soluc:
                                        fichie.write(f'{x}\n')
                        else:
                            with open (fichier, 'w') as fichie:
                                fichie.write("simple\n")
                                for x in soluc :
                                    fichie.write(f'{x}\n')
                    except Exception as error:
                        messagebox.showerror(title="Echec de la sauvegarde", message="Le fichier n'a pu être enregistré pour la raison suivante: "+error+"\nLe logiciel prendra fin!")
                        sys.exit()
                    messagebox.showinfo(title="Sauvegarde réussi", message="Vos fichier ont été correctement sauvegardé! Lisez à l'aide de ce logiciel pour démarrer un quiz")
                    sys.exit()
        class QCM:
            def question():
                global phase, rep, entré
                phase = "quest"
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                titre.config(text="Créer un QCM")
                aide.config(text = "La création se jouera en 3 étapes: Question, réponses disponibles, réponse correcte")
                desc.config(text="Pour l'instant, vous devez entrer une question")
                entré = Entry(root, font=("Calibri light", 12))
                bouton1.config(text="Validez question", command = création.QCM.soluc)
                #bouton2.config(text="Terminez QCM")
                bouton3.config(text="Quitter", command = option.quit_save)
                titre.pack()
                aide.pack()
                desc.pack()
                entré.pack()
                bouton1.pack()
                #bouton2.pack()
                bouton3.pack()
            def soluc():
                global phase, quest, A_e, B_e, C_e, D_e, entré
                reçu = entré.get()
                if reçu == "":
                    messagebox.showerror(title="Question incorrecte", message="Aucune question n'a été entré! Veuillez en entrer une!")
                else:
                    phase = "soluc"
                    quest = quest + [reçu]
                    for c in root.winfo_children():
                        c.destroy()
                    option.défintion()
                    titre.config(text = "Créer un QCM")
                    aide.config(text = "Nous devons maintenant connaitre les 4 réponses possibles\nSi vous voulez créer un QCM avec 2 ou 3 réponses possible uniquement,\nmettez \"rien\" ou un / pour montrer que cela n'est pas une réponse possible")
                    desc.config(text = "Vous devez rentrer ci-dessus, les 4 réponses possible avec 1 bonne réponse et 3 mauvaise réponse\nL'utilisateur devra choisir une réponse (en espérant que ce soit la bonne)")
                    A_e = Entry(font=("Calibri light", 12))
                    B_e = Entry(font=("Calibri light", 12))
                    C_e = Entry(font=("Calibri light", 12))
                    D_e = Entry(font=("Calibri light", 12))
                    bouton1.config(text = "Valider réponse", command=création.QCM.réponse)
                    #bouton2.config(text = "Terminer", command=option.null)
                    bouton3.config(text = "Quitter", command=option.quit_save)
                    titre.pack()
                    aide.pack()
                    A_e.pack()
                    B_e.pack()
                    C_e.pack()
                    D_e.pack()
                    desc.pack()
                    bouton1.pack()
                    #bouton2.pack()
                    bouton3.pack()
            def réponse():
                global phase, soluc, A_e, B_e, C_e, D_e
                if (A_e.get() == "" or B_e.get() == "" or C_e.get() == "" or D_e.get() == ""):
                    messagebox.showerror(title="Réponses incomplètes", message = "Une ou plusieurs réponses sont incomplètes! Veuillez remplir TOUS les champs!")
                else:
                    phase = "rep"
                    soluc.append(A_e.get())
                    soluc.append(B_e.get())
                    soluc.append(C_e.get())
                    soluc.append(D_e.get())
                    A_sav = A_e.get()
                    B_sav = B_e.get()
                    C_sav = C_e.get()
                    D_sav = D_e.get()
                    for c in root.winfo_children():
                        c.destroy()
                    option.défintion()
                    titre.config(text="Créer un QCM")
                    aide.config(text="Enfin vous devez indiquer quelle champs est la bonne réponse")
                    desc.config(text = f"Pour continuer, vous devez cliquer sur la bonne réponse!\nRappel des réponses disponibles:\n{A_sav}\n{B_sav}\n{C_sav}\n{D_sav}")
                    A_b = Button(text = "A", command=création.QCM.A_save)
                    B_b = Button(text = "B", command=création.QCM.B_save)
                    C_b = Button(text = "C", command=création.QCM.C_save)
                    D_b = Button(text = "D", command=création.QCM.D_save)
                    bouton3.config(text = "Quitter", command=option.quit_save)
                    titre.pack()
                    aide.pack()
                    A_b.pack()
                    B_b.pack()
                    C_b.pack()
                    D_b.pack()
                    desc.pack()
                    bouton3.pack()
            def A_save():
                global rep
                rep.append("A")
                mes = messagebox.askyesno(title="Sauvegarder QCM?", message="Voulez-vous sauvegardez?\nEn sauvegardant, votre QCM sera considéré comme étant fini et vous ne pourrez plus le continuer")
                if mes == True:
                    création.QCM.save()
                else:
                    création.QCM.question()
            def B_save():
                global rep
                rep.append("B")
                mes = messagebox.askyesno(title="Sauvegarder QCM?", message="Voulez-vous sauvegardez?\nEn sauvegardant, votre QCM sera considéré comme étant fini et vous ne pourrez plus le continuer")
                if mes == True:
                    création.QCM.save()
                else:
                    création.QCM.question()
            def C_save():
                global rep
                rep.append("C")
                mes = messagebox.askyesno(title="Sauvegarder QCM?", message="Voulez-vous sauvegardez?\nEn sauvegardant, votre QCM sera considéré comme étant fini et vous ne pourrez plus le continuer")
                if mes == True:
                    création.QCM.save()
                else:
                    création.QCM.question()
            def D_save():
                global rep
                rep.append("D")
                mes = messagebox.askyesno(title="Sauvegarder QCM?", message="Voulez-vous sauvegardez?\nEn sauvegardant, votre QCM sera considéré comme étant fini et vous ne pourrez plus le continuer")
                if mes == True:
                    création.QCM.save()
                else:
                    création.QCM.question()
            def save():
                global rep, rang, quest, soluc
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                titre.config(text="En attente d'enregistrement")
                aide.config(text="Via la fenêtre veuillez choisir un répertoire où enregistrer le fichier")
                desc.config(text="Nous allons sauvegardé un fichier QSM qui contiendra vos questions")
                titre.pack()
                aide.pack()
                desc.pack()
                fichier = asksaveasfilename(filetypes=[("Fichier question QCM", "*.qsm")])
                try:
                    if os.name == 'nt':
                        if fichier[-4 : ] == ".qsm":
                            with open (fichier,'w') as fichie:
                                fichie.write("QCM\n")
                                for x in quest:
                                    temp = rep[rang]
                                    fichie.write(f'{x} \\{temp}\\\n')
                                    rang = rang + 1
                        else:
                            with open (fichier+".qsm",'w') as fichie:
                                fichie.write("QCM\n")
                                for x in quest:
                                    temp = rep[rang]
                                    fichie.write(f'{x} \\{temp}\\\n')
                                    rang = rang + 1
                    else:
                        with open (fichier, 'w') as fichie:
                            fichie.write("QCM\n")
                            for x in quest():
                                temp = rep[rang]
                                fichie.write(f'{x} \\{temp}\\\n')
                                rang = rang + 1
                except Exception as error:
                    messagebox.showerror(title="Echec de la sauvegarde", message=f"Le fichier n'a pu être enregistré pour la raison suivante:\n{error}\nLe logiciel prendra fin!")
                    sys.exit()
                desc.config(text="Il faut maintenant enregistrer un fichier RPQ qui contient toutes les réponses de vos question")
                fichier = asksaveasfilename(filetypes=[("Fichier réponse QCM", "*.rpq")])
                try:
                    if os.name == 'nt':
                        if fichier[-4 : ] == ".rpq":
                            with open (fichier,'w') as fichie:
                                fichie.write("QCM\n")
                                for x in soluc:
                                    fichie.write(f'{x}\n')
                        else:
                            with open (fichier+".rpq",'w') as fichie:
                                fichie.write("QCM\n")
                                for x in soluc:
                                    fichie.write(f'{x}\n')
                    else:
                        with open (fichier, 'w') as fichie:
                            fichie.write("QCM")
                            for x in soluc:
                                fichie.write(f'{x}\n')
                except Exception as error:
                    messagebox.showerror(title="Echec de la sauvegarde", message=f"Le fichier n'a pu être enregistré pour la raison suivante:\n{error}\nLe logiciel prendra fin!")
                    sys.exit()
                messagebox.showinfo(title="Sauvegarde réussi", message="Vos fichier ont été correctement sauvegardé! Lisez à l'aide de ce logiciel pour démarrer un quiz")
                sys.exit()
        consol("Script définis")
    class lecture:
        def main():
            titre.config(text="Importez un quiz")
            aide.config(text="Vous allez pouvoir être testé!")
            desc.config(text="Cependant, nous devons d'abord savoir quel type de quiz voulez-vous lire!\nVous devez également posséder un quiz (crée ou reçu par une autre personne).")
            bouton1.config(text="Importer un quiz normale", command=lecture.quiz.load_main)
            bouton2.config(text="Inporter un QCM", command=lecture.QCM.load_main)
        class quiz:
            def load_main():
                titre.config(text="Ouvrir un questionnaire")
                aide.config(text="Nous devons tout d'abords importez le quiz!")
                desc.config(text="Pour cela, appuyer sur le bouton \"Importer\"\nSi finalement vous voulez faire autre chose! Vous pouvez arrêter le logiciel en appuyant sur \"Annuler\"")
                bouton1.config(text="Importer", command=lecture.quiz.load_question)
                bouton2.config(text="Annuler", command = option.quit)
            def load_question():
                global quest, soluc, nb_quest, suite
                fichier = askopenfilename(filetypes=[("Fichier question", "*.qst")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                    suite = False
                with open (fichier, 'r') as fichie:
                    quest = fichie.read().splitlines()
                if quest[0] != "simple":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour des questions simple")
                fichier = askopenfilename(filetypes=[("Fichier réponse quiz", "*.rps")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                with open (fichier, 'r') as fichie:
                    soluc = fichie.read().splitlines()
                if soluc[0] != "simple":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour des questions simple")
                    suite = False
                if suite == True:
                    nb_quest = int(len(quest)) - 1
                    print(nb_quest)
                    print(quest)
                    lecture.quiz.test()
            def test():
                global quest, nb_quest, entré, question
                question = random.randint(1, nb_quest)
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                titre.config(text="Répond à la question suivante:")
                aide.config(text=quest[question])
                desc.config(text = "Répondez dans le champs ci-dessous! Pour valider la réponse appuyer sur \"Valider\"")
                entré = Entry()
                bouton1.config(text="Valider", command=lecture.quiz.check)
                bouton2.config(text = "Quitter", command=option.aband)
                titre.pack()
                aide.pack()
                desc.pack()
                entré.pack()
                bouton1.pack()
                bouton2.pack()
            def check():
                global soluc, entré, essaie, question
                don = entré.get()
                if don == "":
                    messagebox.showerror(title="Réponse incomplète", message="Aucune réponse n'a été donné!")
                if don == soluc[question]:
                    messagebox.showinfo(title="Bonne réponse", message="La réponse donné est juste! Nous allons passé à la question suivante")
                    essaie = 2
                    lecture.quiz.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"La réponse donné est fausse!\nIl vous reste {essaie} essais\nAttention à l'orthographe, la ponctuation et les majuscules")
                        essaie = essaie - 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"La réponse donné est fausse!\nIl vous reste {essaie} essai\nAttention à l'orthographe, la ponctuation et les majuscules")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"La bonne réponse est: {soluc[question]}\nNous allons passé à la question suivante")
                        essaie = 2
                        lecture.quiz.test()
        class QCM:
            def load_main():
                titre.config(text="Ouvrir un QCM")
                aide.config(text="Nous devons tout d'abords importez le QCM!")
                desc.config(text="Pour cela, appuyer sur le bouton \"Importer\"\nSi finalement vous voulez faire autre chose! Vous pouvez arrêter le logiciel en appuyant sur \"Annuler\"")
                bouton1.config(text="Importer", command=lecture.QCM.load_question)
                bouton2.config(text="Annuler", command = option.quit)  
            def load_question():
                global quest, soluc, nb_quest, suite
                fichier = askopenfilename(filetypes=[("Fichier question", "*.qsm")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                    suite = False
                with open (fichier, 'r') as fichie:
                    quest = fichie.read().splitlines()
                if quest[0] != "QCM":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour les QCM")
                fichier = askopenfilename(filetypes=[("Fichier réponse quiz", "*.rpq")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                with open (fichier, 'r') as fichie:
                    soluc = fichie.read().splitlines()
                if soluc[0] != "QCM":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour les QCM")
                    suite = False
                if suite == True:
                    nb_quest = int(len(quest)) - 1
                    print(nb_quest)
                    print(quest)
                    print(soluc)
                    lecture.QCM.test()
            def test():
                global quest, nb_quest, question, rep, soluc
                num_question = random.randint(1, nb_quest)
                question = quest[num_question]
                rep = question[-2:-1]
                question = question[:-3]
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                if rep == "A" or rep == "B" or rep == "C" or rep == "D":
                    pass
                else:
                    consol(rep)
                    messagebox.showerror(title="Erreur critique", message="Une erreur critique est survenue! Votre QCM est très certainement corrompue\nVeuillez en recrée un!")
                    sys.exit()
                titre.config(text="Choisie une réponse")
                aide.config(text=question)
                desc.config(text="Cliquer sur la bonne réponse")
                result = num_question
                a_t = (num_question-1)*4 + 1
                b_t = (num_question-1)*4 + 2
                c_t = (num_question-1)*4 + 3
                d_t = (num_question-1)*4 + 4
                a_b = Button(text=soluc[a_t], command=lecture.QCM.rep_a)
                b_b = Button(text=soluc[b_t], command=lecture.QCM.rep_b)
                c_b = Button(text=soluc[c_t], command=lecture.QCM.rep_c)
                d_b = Button(text=soluc[d_t], command=lecture.QCM.rep_d)
                bouton1.config(text="Quitter", command=option.aband)
                titre.pack()
                aide.pack()
                desc.pack()
                a_b.pack()
                b_b.pack()
                c_b.pack()
                d_b.pack()
            def rep_a():
                global rep, essaie
                if rep == "A":
                    messagebox.showinfo(title="Bonne réponse", message="Il s'agit de la bonne réponse!\nNous allons passer à la question suivante")
                    essaie = 2
                    lecture.QCM.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 2 essais!")
                        essaie = 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 1 essai!")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"Ce n'est pas la bonne réponse!\nLa bonne réponse était la case: {rep}!")
                        essaie = 2
                        lecture.QCM.test()
            def rep_b():
                global rep, essaie
                if rep == "B":
                    messagebox.showinfo(title="Bonne réponse", message="Il s'agit de la bonne réponse!\nNous allons passer à la question suivante")
                    essaie = 2
                    lecture.QCM.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 2 essais!")
                        essaie = 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 1 essai!")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"Ce n'est pas la bonne réponse!\nLa bonne réponse était la case: {rep}!")
                        essaie = 2
                        lecture.QCM.test()
            def rep_c():
                global rep, essaie
                if rep == "C":
                    messagebox.showinfo(title="Bonne réponse", message="Il s'agit de la bonne réponse!\nNous allons passer à la question suivante")
                    essaie = 2
                    lecture.QCM.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 2 essais!")
                        essaie = 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 1 essai!")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"Ce n'est pas la bonne réponse!\nLa bonne réponse était la case: {rep}!")
                        essaie = 2
                        lecture.QCM.test()
            def rep_d():
                global rep, essaie
                if rep == "D":
                    messagebox.showinfo(title="Bonne réponse", message="Il s'agit de la bonne réponse!\nNous allons passer à la question suivante")
                    essaie = 2
                    lecture.QCM.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 2 essais!")
                        essaie = 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 1 essai!")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"Ce n'est pas la bonne réponse!\nLa bonne réponse était la case: {rep}!")
                        essaie = 2
                        lecture.QCM.test()
    option.défintion() 
    option.main()
    consol("Fenêtre crée")
    print(sys.exc_info())
    root.mainloop()
except Exception as error:
    messagebox.showerror(title="Erreur fatale", message=f"Une erreur innatendu est survenue!\n{error}")
    crash = crash + [error]
    try:
        with open("crash.txt", 'w') as fichier:
            for crash in crash:
                fichier.write(f'{crash}\n')
    except PermissionError:
        messagebox.showerror(titre="Echec de l'écriture du rapport", message="Une erreur est survenue lors de l'écriture du rapport")
        sys.exit()
    messagebox.showinfo(title="Rapport écrit!", message="Rapport écrit dans \"crash.txt\"")
