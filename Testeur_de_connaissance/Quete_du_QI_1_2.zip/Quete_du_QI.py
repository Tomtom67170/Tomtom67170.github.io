import sys
from tabnanny import check
from tkinter import messagebox, Entry, Label, Menu, Tk, Button, Canvas
from tkinter.filedialog import askopenfilename, asksaveasfilename
import os
import random
from unittest import skip
crash = [0]
def consol(phrase):
    global crash
    print(phrase)
    crash = crash + [phrase]
quest = []
soluc = []
rep = ""
rang = 0
suite = True
essaie = 2
question_passé = []
page = 0
version = "1.2"
consol(os.name)
try:
    consol("Ceci est la console. La fermer entrainera l'arrêt du programme")
    from tkinter.filedialog import asksaveasfilename
    #import time
    import sys
    root = Tk()
    consol("Module importé, fenêtre crée")
    class erreur:
        def error1():
            messagebox.showerror(title="Erreur",message="Cette action n'est pas possible pour le moment! Veuillez entrer au moins une question puis une réponse!")
        def error2():
            messagebox.showerror(title="Erreur",message="Cette fonctionnalité n'est pas disponible pour le moment! Vous êtes sur une version de dévellopement")
    class option:
        global titre, aide, desc, bouton1, bouton2, bouton3
        class nav:
            class question:
                def sup():
                    global page
                    del quest[page], soluc[page]
                    création.question.rafraichir()
                def previous():
                    global page
                    page -= 1
                    création.question.rafraichir()
                def next():
                    global page
                    page += 1
                    création.question.rafraichir()
            class QCM:
                def sup():
                    global page
                    a_t = (page)*4 + 1
                    b_t = (page)*4 + 2
                    c_t = (page)*4 + 3
                    d_t = (page)*4 + 4
                    del quest[page], soluc[a_t], soluc[b_t], soluc[c_t], soluc[d_t]
                    création.QCM.question()
                def previous():
                    global page
                    page -= 1
                    création.QCM.question()
                def next():
                    global page
                    page += 1
                    création.QCM.question()         
        def défintion():
            for c in root.winfo_children():
                c.destroy()
            global titre, aide, desc, bouton1, bouton2, bouton3
            root.title("Quête du QI")
            root.geometry("890x350")
            root.minsize(870, 340)
            if os.name == 'nt':
                root.iconbitmap("logo.ico")
            titre = Label(root,text="Menu principal", font=("Calibri light", 30))
            aide = Label(root,text="Comment ça marche?", font=("Calibri light", 20))
            desc = Label(root,text="Ce logiciel simple à utiliser vous permettra de réviser en faisait des quizs réalisés par vous ou par des camarades\n Appuyer sur \"Créer un quiz\" pour créer un quiz et laisser-vous guider...\n Si au contraire vous avez déjà un quiz, appuyer sur \"Importer un quiz\" Pour ouvrir un quiz déjà existant!", font=("Calibri", 12))
            bouton1 = Button(root,text="Créer un quiz", command=création.Créer)
            bouton3 = Button(root,text="Importer quiz", command=lecture.main)
            bouton2 = Button(root,text="Modifier quiz", command=modifier.main)
            consol("Fenêtre crée")
        def taille():
            global titre, aide, desc, bouton1, bouton2
            width = root.winfo_width() 
            height = root.winfo_height()
            print(width,"x",height)
        def skip():
            global essaie
            essaie = 0
            lecture.quiz.check()
        def def_menu():
            global titre, aide, desc, bouton1, bouton2
            m = Menu(root)
            menubis = Menu(root)
            action = Menu(root)
            debug = Menu(root)
            m.add_cascade(label ="Logiciel", menu = menubis)
            m.add_cascade(label ="Action", menu = action)
            m.add_cascade(label ="Debug", menu = debug)
            menubis.add_command (label = "Créer quiz", command=création.Créer)
            menubis.add_command (label = "Modifier quiz", command=modifier.main)
            menubis.add_command (label = "Importer quiz", command=lecture.main)
            menubis.add_command (label="À propos...", command=option.version)
            action.add_command (label = "Fermer", command=option.quit)
            action.add_command (label = "Menu", command=option.reset)
            debug.add_command (label= "Taille", command= option.taille)
            root.config(menu = m, width = 200)
        def quit():
            root.destroy()
            sys.exit()
        def main():
            global titre, aide, desc, bouton1, bouton2
            consol("main")
            option.def_menu()
            titre.config(text="Menu principal")
            aide.config(text="Comment ça marche?")
            desc.config(text="Ce logiciel simple à utiliser vous permettra de réviser en faisait des quizs réalisés par vous ou par des camarades\n Appuyer sur \"Créer un quiz\" pour créer un quiz et laisser-vous guider...\n Si au contraire vous avez déjà un quiz, appuyer sur \"Importer un quiz\" Pour ouvrir un quiz déjà existant!")
            bouton1.config(command=création.Créer)
            bouton2.config(command=modifier.main)
            titre.pack()
            aide.pack()
            desc.pack()
            bouton1.pack()
            bouton2.pack()
            bouton3.pack()
            consol("main prêt")
        def reset():
            option.défintion()
            option.main()
        def null():
            pass
        def quit_save():
            warn = messagebox.askyesno(title="Voulez-vous quitter", message="Voulez-vous continuer? Toute données non sauvegardé sera perdu")
            if warn == True:
                root.destroy()
                sys.exit()
        def version():
            ver = Tk()
            ver.title("À propos...")
            nom = Label(ver,text="Quête du QI (Testeur de connaisance)", font=("Calibri light", 30))
            plus = Label(ver, text=f"Ce logiciel à été crée et distribué gratuitement par Tomservice\nVersion: {version}\nVersion de l'interpréteur Python:\n"+sys.version+"\nLogiciel open-source\nTomservice 2023")
            nom.pack()
            plus.pack()
            ver.mainloop
        def aband():
            message = messagebox.askyesno(title="Quitter",message="Voulez-vous vraiment quitter?")
            if message == True:
                sys.exit()
    class création:
        def Créer():
            global titre, aide, desc, bouton1, bouton2
            consol("créer")
            option.def_menu()
            consol("Menu crée")
            bouton3.destroy()
            titre.config(text="Création d'un quiz")
            aide.config(text="Quelle type de questionnaire crée?")
            desc.config(text="Explications:\nLes questions simple sont des quizs où l'utilisateur devra entrer la réponse au clavier\nLes QCM sont des questions où l'utlisateur devra répondre A, B, C ou D")
            bouton1.config(text="Questions simples", command= création.question.rafraichir)
            bouton2.config(text="QCM (Choix multiples)", command = création.QCM.question)
            bouton3.destroy()
            consol("créer prêt")
        class question:
            def rafraichir():
                global entré, phase, nav, mode
                mode = "simple"
                phase = "quest"
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                if page == len(quest): titre.config(text="Créer une question")
                else: titre.config(text="Modificer une question")
                aide.config(text="Veuillez entrer une question")
                desc.config(text="Veuillez indiquez dans le champ ci-dessous votre question\nAppuyer ensuite sur \"Valider question\" pour entrer une réponse")
                entré = Entry(font=("Calibri light", 12),width=50)
                if page < len(quest):
                    entré.insert(0, quest[page])
                bouton1.config( text="Valider question", command = création.question.réponse, font=("Calibri light",12))
                bouton2.config(text="Terminer", command= création.question.save, font=("Calibri light",12))
                bouton3 = Button(text="Quitter", command=option.quit_save, font=("Calibri light",12))
                nav = Canvas(root)
                del_button = Button(nav, text="Supprimer la question",font=("Calibri light",12))
                next_button = Button(nav, text="Suivant", font=("Calibri light",12))
                previous_button = Button(nav, text="Précédent", font=("Calibri light",12))
                if page == 0: previous_button.config(fg="#808080", command=option.null)
                else: previous_button.config(command= option.nav.question.previous)
                if page == len(quest): 
                    next_button.config(fg="#808080", command=option.null)
                    del_button.config(fg="#808080", command=option.null)
                else: 
                    next_button.config(command= option.nav.question.next)
                    del_button.config(command= option.nav.question.sup)
                titre.pack()
                aide.pack()
                desc.pack()
                entré.pack()
                bouton1.pack()
                bouton2.pack()
                bouton3.pack()
                nav.pack()
                del_button.grid(column=1, row=0)
                next_button.grid(column=2,row=0)
                previous_button.grid(column=0,row=0)
            def réponse ():
                global entré, phase, quest
                actuel = entré.get()
                if actuel == "":
                    messagebox.showerror(title="Impossible de continuer", message="Aucune question n'a été entré!")
                else:
                    nav.destroy()
                    phase = "soluc"
                    aide.config(text="Veuillez entrer une réponse")
                    desc.config(text="Veuillez indiquez dans le champ en dessous la réponse adéquate a votre question\nAppuyer ensuite sur \"Valider question\" pour entrer une autre question\nSi votre quiz est fini, appuyer sur \"Terminer\"\nRépondre \\ pour annuler question")
                    actuel = entré.get()
                    if page == len(quest): quest = quest + [actuel]
                    else: quest[page] = actuel
                    entré.delete("0","end")
                    if page < len(soluc):
                        entré.insert(0, soluc[page])
                    bouton1.config(command = création.question.question)
                    bouton2.config(command = création.question.save)
            def question():
                global entré, phase, soluc, page
                phase = "quest"
                actuel = entré.get()
                if actuel == "\\":
                    demande = messagebox.askyesno(title="Annuler question",message="Êtes vous sur de vouloir annuler votre question?")
                    if demande == True:
                        del quest[page]
                        try:
                            del soluc[page]
                        except IndexError:
                            consol("soluc[page] non supprimé car l'index est introuvable")
                        création.question.rafraichir()
                elif actuel == "":
                    messagebox.showerror(title="Impossible de continuer", message="Aucune réponse n'a été entré")
                elif actuel != "":
                    phase = "quest"
                    aide.config(text="Veuillez entrer une question")
                    desc.config(text="Veuillez indiquez dans le champ en dessous votre question\nAppuyer ensuite sur \"Valider question\" pour entrer une réponse")
                    actuel = entré.get()
                    if page == len(soluc): 
                        soluc = soluc + [actuel]
                        page += 1
                    else: soluc[page] = actuel
                    création.question.rafraichir()
                    # entré.delete("0","end")
                    # bouton1.config(text = "Valider question", command=création.question.réponse)
            def save():
                global entré, quest, soluc, page
                actuel = entré.get()
                warn = messagebox.askyesno(title="Sauvegarder?", message="Voulez sauvegarder maintenant?")
                save = False
                if warn == True:
                    if len(actuel) != 0:
                        if phase == "soluc":
                            actuel = entré.get()
                            if page == len(soluc): 
                                soluc = soluc + [actuel]
                            else: soluc[page] = actuel
                        save = True
                    else:
                        if soluc == []:
                            messagebox.showerror(title="Erreur", message="Vous devez entrer au moins une réponse!")
                        else:
                            if phase == "quest":
                                pass
                            else:
                                soluc = soluc + [actuel]
                            save = True
                if save:
                    print("boucle save == True")
                    titre.config(text="En attente d'enregistrement")
                    aide.config(text="Via la fenêtre veuillez choisir un répertoire où enregistrer le fichier")
                    desc.config(text="Nous allons sauvegardé un fichier QST qui contiendra vos questions")
                    entré.delete("1", "end")
                    bouton1.config(command=option.null)
                    bouton2.config(command=option.null)
                    fichier = asksaveasfilename(filetypes=[("Fichier question", "*.qst")])
                    try:
                        if os.name == 'nt':
                            if fichier[-4:] == ".qst":
                                with open (fichier,'w') as fichie:
                                    fichie.write("simple\n")
                                    for x in quest:
                                        fichie.write(f'{x}\n')
                            else:
                                with open (fichier+".qst",'w') as fichie:
                                    fichie.write("simple\n")
                                    for x in quest:
                                        fichie.write(f'{x}\n')
                        else:
                            with open (fichier, 'w') as fichie:
                                fichie.write("simple\n")
                                for x in quest():
                                    fichie.write(f'{x}\n')
                    except Exception as error:
                        messagebox.showerror(title="Echec de la sauvegarde", message=f"Le fichier n'a pu être enregistré pour la raison suivante:\n{error}\nLe logiciel prendra fin!")
                        sys.exit()
                    desc.config(text="Il faut maintenant enregistrer un fichier RPS qui contient toutes les réponses de vos question")
                    fichier = asksaveasfilename(filetypes=[("Fichier réponse", "*.rps")])
                    try:
                        if os.name == 'nt':
                            if fichier[-4:] == ".rps":
                                with open (fichier, 'w') as fichie:
                                    fichie.write("simple\n")
                                    for x in soluc:
                                        fichie.write(f'{x}\n')                            
                            else:
                                with open (fichier+".rps", 'w') as fichie:
                                    fichie.write("simple\n")
                                    for x in soluc:
                                        fichie.write(f'{x}\n')
                        else:
                            with open (fichier, 'w') as fichie:
                                fichie.write("simple\n")
                                for x in soluc :
                                    fichie.write(f'{x}\n')
                    except Exception as error:
                        messagebox.showerror(title="Echec de la sauvegarde", message="Le fichier n'a pu être enregistré pour la raison suivante: "+error+"\nLe logiciel prendra fin!")
                        sys.exit()
                    messagebox.showinfo(title="Sauvegarde réussi", message="Vos fichier ont été correctement sauvegardé! Lisez à l'aide de ce logiciel pour démarrer un quiz")
                    sys.exit()
        class QCM:
            def question():
                global phase, rep, entré, page
                phase = "quest"
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                if page == len(quest): 
                    titre.config(text="Créer un QCM")
                    aide.config(text = "La création d'un QCM ce joue en 3 étapes")
                else: titre.config(text="Modificer un QCM")
                desc.config(text="Pour l'instant, vous devez entrer une question")
                entré = Entry(root, font=("Calibri light", 12),width=50)
                if page < len(quest):
                    entré.insert(0, quest[page][:-4])
                    rep = quest[page][-2]
                bouton1.config(text="Validez question", command = création.QCM.soluc)
                bouton2.config(text="Terminez QCM", command=création.QCM.save)
                bouton3.config(text="Quitter", command = option.quit_save)
                nav = Canvas(root)
                next_button = Button(nav, text="Suivant", fg = "#808080")
                previous_button = Button(nav, text="Précédent", fg = "#808080")
                del_button = Button(nav, text="Supprimer la question", fg="#808080")
                if page != 0:
                    previous_button.config(fg="#000000", command=option.nav.QCM.previous)
                if page != len(quest):
                    del_button.config(fg = "#000000", command=option.nav.question.sup)
                    next_button.config(fg = "#000000", command=option.nav.QCM.next)
                titre.pack()
                aide.pack()
                desc.pack()
                entré.pack()
                bouton1.pack()
                bouton2.pack()
                bouton3.pack()
                nav.pack()
                previous_button.grid(column=0, row = 0)
                del_button.grid(column = 1, row = 0)
                next_button.grid(column = 2, row = 0)
            def soluc():
                global phase, quest, A_e, B_e, C_e, D_e, entré, page, a_t, b_t, c_t, d_t, question
                reçu = entré.get()
                if reçu == "":
                    messagebox.showerror(title="Question incorrecte", message="Aucune question n'a été entré! Veuillez en entrer une!")
                else:
                    phase = "soluc"
                    question = reçu
                    for c in root.winfo_children():
                        c.destroy()
                    option.défintion()
                    titre.config(text = "Créer un QCM")
                    aide.config(text = "Nous devons maintenant connaitre les 4 réponses possibles\nSi vous voulez créer un QCM avec 2 ou 3 réponses possible uniquement,\nmettez \"rien\" ou un / pour montrer que cela n'est pas une réponse possible")
                    desc.config(text = "Vous devez rentrer ci-dessus, les 4 réponses possible avec 1 bonne réponse et 3 mauvaise réponse\nL'utilisateur devra choisir une réponse (en espérant que ce soit la bonne)")
                    A_e = Entry(font=("Calibri light", 12),width=40)
                    B_e = Entry(font=("Calibri light", 12),width=40)
                    C_e = Entry(font=("Calibri light", 12),width=40)
                    D_e = Entry(font=("Calibri light", 12),width=40)
                    a_t = (page)*4 + 1
                    b_t = (page)*4 + 2
                    c_t = (page)*4 + 3
                    d_t = (page)*4 + 4
                    if page < len(quest):
                        A_e.insert(0, soluc[a_t])
                        B_e.insert(0, soluc[b_t])
                        C_e.insert(0, soluc[c_t])
                        D_e.insert(0, soluc[d_t])
                    bouton1.config(text = "Valider réponse", command=création.QCM.réponse)
                    #bouton2.config(text = "Terminer", command=option.null)
                    bouton3.config(text = "Quitter", command=option.quit_save)
                    titre.pack()
                    aide.pack()
                    A_e.pack()
                    B_e.pack()
                    C_e.pack()
                    D_e.pack()
                    desc.pack()
                    bouton1.pack()
                    #bouton2.pack()
                    bouton3.pack()
            def réponse():
                global phase, soluc, A_e, B_e, C_e, D_e, A_sav, B_sav, C_sav, D_sav, rep
                if (A_e.get() == "" or B_e.get() == "" or C_e.get() == "" or D_e.get() == ""):
                    messagebox.showerror(title="Réponses incomplètes", message = "Une ou plusieurs réponses sont incomplètes! Veuillez remplir TOUS les champs!")
                else:
                    phase = "rep"
                    A_sav = A_e.get()
                    B_sav = B_e.get()
                    C_sav = C_e.get()
                    D_sav = D_e.get()
                    for c in root.winfo_children():
                        c.destroy()
                    option.défintion()
                    titre.config(text="Créer un QCM")
                    aide.config(text="Enfin vous devez indiquer quelle champs est la bonne réponse")
                    desc.config(text = f"Pour continuer, vous devez cliquer sur la bonne réponse!\nRappel des réponses disponibles:\n{A_sav}\n{B_sav}\n{C_sav}\n{D_sav}")
                    A_b = Button(text = "A", command=création.QCM.A_save)
                    B_b = Button(text = "B", command=création.QCM.B_save)
                    C_b = Button(text = "C", command=création.QCM.C_save)
                    D_b = Button(text = "D", command=création.QCM.D_save)
                    if page < len(quest):
                        if rep == "A":
                            A_b.config(bg="#198807")
                        elif rep == "B":
                            B_b.config(bg="#198807")
                        elif rep == "C":
                            C_b.config(bg="#198807")
                        elif rep == "D":
                            D_b.config(bg="#198807")
                        else:
                            messagebox.showerror(title="Erreur de format", message="Impossible de récupérer la bonne réponse attribuer à la question!")
                            rep = "A"
                    else:
                        soluc.append(A_sav)
                        soluc.append(B_sav)
                        soluc.append(C_sav)
                        soluc.append(D_sav)
                    bouton3.config(text = "Quitter", command=option.quit_save)
                    titre.pack()
                    aide.pack()
                    A_b.pack()
                    B_b.pack()
                    C_b.pack()
                    D_b.pack()
                    desc.pack()
                    bouton3.pack()
            def A_save():
                global quest, page, question
                if len(quest) == page:
                    quest.append(f"{question} \\A\\")
                    page += 1   
                else:
                    quest[page] = f"{question} \\A\\"
                    soluc[a_t] = A_sav
                    soluc[b_t] = B_sav
                    soluc[c_t] = C_sav
                    soluc[d_t] = D_sav
                création.QCM.question()
            def B_save():
                global quest, page, question
                if len(quest) == page:
                    quest.append(f"{question} \\B\\")
                    page += 1
                else:
                    quest[page] = f"{question} \\B\\"
                    soluc[a_t] = A_sav
                    soluc[b_t] = B_sav
                    soluc[c_t] = C_sav
                    soluc[d_t] = D_sav
                création.QCM.question()
            def C_save():
                global quest, page, question
                if len(quest) == page:
                    quest.append(f"{question} \\C\\")
                    page += 1
                else:
                    quest[page] = f"{question} \\C\\"
                    soluc[a_t] = A_sav
                    soluc[b_t] = B_sav
                    soluc[c_t] = C_sav
                    soluc[d_t] = D_sav
                création.QCM.question()
            def D_save():
                global quest, page, question
                if len(quest) == page:
                    quest.append(f"{question} \\D\\")
                    page += 1
                else:
                    quest[page] = f"{question} \\D\\"
                    soluc[a_t] = A_sav
                    soluc[b_t] = B_sav
                    soluc[c_t] = C_sav
                    soluc[d_t] = D_sav
                création.QCM.question()
            def save():
                global rep, rang, quest, soluc
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                titre.config(text="En attente d'enregistrement")
                aide.config(text="Via la fenêtre veuillez choisir un répertoire où enregistrer le fichier")
                desc.config(text="Nous allons sauvegardé un fichier QSM qui contiendra vos questions")
                titre.pack()
                aide.pack()
                desc.pack()
                fichier = asksaveasfilename(filetypes=[("Fichier question QCM", "*.qsm")])
                try:
                    if os.name == 'nt':
                        if fichier[-4:].lower() == ".qsm":
                            with open (fichier,'w') as fichie:
                                fichie.write("QCM\n")
                                for x in quest:
                                    fichie.write(f"{x}\n")
                                    rang = rang + 1
                        else:
                            with open (fichier+".qsm",'w') as fichie:
                                fichie.write("QCM\n")
                                for x in quest:
                                    fichie.write(f"{x}\n")
                    else:
                        with open (fichier, 'w') as fichie:
                            fichie.write("QCM\n")
                            for x in quest:
                                fichie.write(f"{x}\n")
                except Exception as error:
                    messagebox.showerror(title="Echec de la sauvegarde", message=f"Le fichier n'a pu être enregistré pour la raison suivante:\n{error}\nLe logiciel prendra fin!")
                    sys.exit()
                desc.config(text="Il faut maintenant enregistrer un fichier RPQ qui contient toutes les réponses de vos question")
                fichier = asksaveasfilename(filetypes=[("Fichier réponse QCM", "*.rpq")])
                del soluc[0]
                try:
                    if os.name == 'nt':
                        if fichier[-4 : ] == ".rpq":
                            with open (fichier,'w') as fichie:
                                fichie.write("QCM\n")
                                for x in soluc:
                                    fichie.write(f'{x}\n')
                        else:
                            with open (fichier+".rpq",'w') as fichie:
                                fichie.write("QCM\n")
                                for x in soluc:
                                    fichie.write(f'{x}\n')
                    else:
                        with open (fichier, 'w') as fichie:
                            fichie.write("QCM")
                            for x in soluc:
                                fichie.write(f'{x}\n')
                except Exception as error:
                    messagebox.showerror(title="Echec de la sauvegarde", message=f"Le fichier n'a pu être enregistré pour la raison suivante:\n{error}\nLe logiciel prendra fin!")
                    sys.exit()
                messagebox.showinfo(title="Sauvegarde réussi", message="Vos fichier ont été correctement sauvegardé! Lisez à l'aide de ce logiciel pour démarrer un quiz")
                sys.exit()
        consol("Script définis")
    class lecture:
        def main():
            titre.config(text="Importez un quiz")
            aide.config(text="Vous allez pouvoir être testé!")
            desc.config(text="Cependant, nous devons d'abord savoir quel type de quiz voulez-vous lire!\nVous devez également posséder un quiz (crée ou reçu par une autre personne).")
            bouton1.config(text="Importer un quiz normale", command=lecture.quiz.load_main)
            bouton2.config(text="Inporter un QCM", command=lecture.QCM.load_main)
            bouton3.destroy()
        class quiz:
            def load_main():
                titre.config(text="Ouvrir un questionnaire")
                aide.config(text="Nous devons tout d'abords importez le quiz!")
                desc.config(text="Pour cela, appuyer sur le bouton \"Importer\"\nSi finalement vous voulez faire autre chose! Vous pouvez arrêter le logiciel en appuyant sur \"Annuler\"")
                bouton1.config(text="Importer", command=lecture.quiz.load_question)
                bouton2.config(text="Annuler", command = option.quit)
            def load_question():
                global quest, soluc, nb_quest, suite, clear
                suite = True
                fichier = askopenfilename(filetypes=[("Fichier question", "*.qst")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                    suite = False
                with open (fichier, 'r') as fichie:
                    quest = fichie.read().splitlines()
                if quest[0] != "simple":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour des questions simple")
                fichier = askopenfilename(filetypes=[("Fichier réponse quiz", "*.rps")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                with open (fichier, 'r') as fichie:
                    soluc = fichie.read().splitlines()
                if soluc[0] != "simple":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour des questions simple")
                    suite = False
                if suite == True:
                    nb_quest = int(len(quest)) - 1
                    print(nb_quest)
                    print(quest)
                    clear = True
                    lecture.quiz.test()
            def test():
                global quest, nb_quest, entré, question, question_passé
                question = random.randint(1, nb_quest)
                if len(question_passé) == nb_quest:
                    if clear == True:
                        messagebox.showinfo(title="Quiz completé!", message="Félicitations, ce quiz a été complété avec un sans faute!")
                    warn = messagebox.askyesno(title="Quiz completé!", message="Vous avez répondu juste à toutes les questions du quiz!\nVoulez-vous quitter?")
                    if warn == True:
                        sys.exit()
                    else:
                        question = random.randint(1, nb_quest)
                        question_passé = []
                else:
                    while question in question_passé:
                        question = random.randint(1, nb_quest)
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                titre.config(text="Répond à la question suivante:")
                aide.config(text=quest[question])
                desc.config(text = "Répondez dans le champs ci-dessous! Pour valider la réponse appuyer sur \"Valider\"")
                entré = Entry(font=("Calibri light", 12),width=50)
                bouton1.config(text="Valider", command=lecture.quiz.check)
                passer = Button(text="Passer",command=option.skip)
                bouton2.config(text = "Quitter", command=option.aband)
                titre.pack()
                aide.pack()
                desc.pack()
                entré.pack()
                bouton1.pack()
                passer.pack()
                bouton2.pack()
            def check():
                global soluc, entré, essaie, question, clear
                don = entré.get()
                if don == soluc[question]:
                    messagebox.showinfo(title="Bonne réponse", message="La réponse donné est juste! Nous allons passé à la question suivante")
                    essaie = 2
                    question_passé.append(question)
                    lecture.quiz.test()
                else:
                    clear = False
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"La réponse donné est fausse!\nIl vous reste {essaie} essais\nAttention à l'orthographe, la ponctuation et les majuscules")
                        essaie = essaie - 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"La réponse donné est fausse!\nIl vous reste {essaie} essai\nAttention à l'orthographe, la ponctuation et les majuscules")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"La bonne réponse est: {soluc[question]}\nNous allons passé à la question suivante")
                        essaie = 2
                        lecture.quiz.test()
        class QCM:
            def load_main():
                titre.config(text="Ouvrir un QCM")
                aide.config(text="Nous devons tout d'abords importez le QCM!")
                desc.config(text="Pour cela, appuyer sur le bouton \"Importer\"\nSi finalement vous voulez faire autre chose! Vous pouvez arrêter le logiciel en appuyant sur \"Annuler\"")
                bouton1.config(text="Importer", command=lecture.QCM.load_question)
                bouton2.config(text="Annuler", command = option.quit)  
            def load_question():
                global quest, soluc, nb_quest, suite
                suite = True
                fichier = askopenfilename(filetypes=[("Fichier question", "*.qsm")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                    suite = False
                with open (fichier, 'r') as fichie:
                    quest = fichie.read().splitlines()
                if quest[0] != "QCM":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour les QCM")
                fichier = askopenfilename(filetypes=[("Fichier réponse quiz", "*.rpq")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                with open (fichier, 'r') as fichie:
                    soluc = fichie.read().splitlines()
                if soluc[0] != "QCM":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour les QCM")
                    suite = False
                if suite == True:
                    del quest[0]
                    nb_quest = int(len(quest)) - 1
                    lecture.QCM.test()
            def test():
                global quest, nb_quest, question, rep, soluc, question_passé, num_question
                num_question = random.randint(0, nb_quest)
                question = ""
                if len(question_passé) == nb_quest + 1:
                    warn = messagebox.askyesno(title="Quiz completé!", message="Vous avez répondu juste à toutes les questions du quiz!\nVoulez-vous quitter?")
                    if warn == True:
                        sys.exit()
                    else:
                        num_question = random.randint(0, nb_quest)
                        question_passé = []
                else:
                    while num_question in question_passé:
                        num_question = random.randint(0, nb_quest)
                print(num_question)
                question = quest[num_question]
                rep = question[-2:-1]
                question = question[:-4]
                for c in root.winfo_children():
                    c.destroy()
                option.défintion()
                if rep == "A" or rep == "B" or rep == "C" or rep == "D":
                    pass
                else:
                    consol(rep)
                    messagebox.showerror(title="Erreur critique", message="Une erreur critique est survenue! Votre QCM est très certainement corrompue\nVeuillez en recrée un!")
                    sys.exit()
                titre.config(text="Choisie une réponse")
                aide.config(text=question)
                desc.config(text="Cliquer sur la bonne réponse")
                result = num_question
                a_t = (num_question)*4 + 1
                b_t = (num_question)*4 + 2
                c_t = (num_question)*4 + 3
                d_t = (num_question)*4 + 4
                a_b = Button(text=soluc[a_t], command=lecture.QCM.rep_a)
                b_b = Button(text=soluc[b_t], command=lecture.QCM.rep_b)
                c_b = Button(text=soluc[c_t], command=lecture.QCM.rep_c)
                d_b = Button(text=soluc[d_t], command=lecture.QCM.rep_d)
                bouton1.config(text="Quitter", command=option.aband)
                titre.pack()
                aide.pack()
                desc.pack()
                a_b.pack()
                b_b.pack()
                c_b.pack()
                d_b.pack()
            def rep_a():
                global rep, essaie, num_question
                if rep == "A":
                    messagebox.showinfo(title="Bonne réponse", message="Il s'agit de la bonne réponse!\nNous allons passer à la question suivante")
                    essaie = 2
                    question_passé.append(num_question)
                    lecture.QCM.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 2 essais!")
                        essaie = 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 1 essai!")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"Ce n'est pas la bonne réponse!\nLa bonne réponse était la case: {rep}!")
                        essaie = 2
                        lecture.QCM.test()
            def rep_b():
                global rep, essaie, num_question
                if rep == "B":
                    messagebox.showinfo(title="Bonne réponse", message="Il s'agit de la bonne réponse!\nNous allons passer à la question suivante")
                    essaie = 2
                    question_passé.append(num_question)
                    lecture.QCM.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 2 essais!")
                        essaie = 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 1 essai!")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"Ce n'est pas la bonne réponse!\nLa bonne réponse était la case: {rep}!")
                        essaie = 2
                        lecture.QCM.test()
            def rep_c():
                global rep, essaie, num_question
                if rep == "C":
                    messagebox.showinfo(title="Bonne réponse", message="Il s'agit de la bonne réponse!\nNous allons passer à la question suivante")
                    essaie = 2
                    question_passé.append(num_question)
                    lecture.QCM.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 2 essais!")
                        essaie = 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 1 essai!")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"Ce n'est pas la bonne réponse!\nLa bonne réponse était la case: {rep}!")
                        essaie = 2
                        lecture.QCM.test()
            def rep_d():
                global rep, essaie, num_question
                if rep == "D":
                    messagebox.showinfo(title="Bonne réponse", message="Il s'agit de la bonne réponse!\nNous allons passer à la question suivante")
                    essaie = 2
                    question_passé.append(num_question)
                    lecture.QCM.test()
                else:
                    if essaie == 2:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 2 essais!")
                        essaie = 1
                    elif essaie == 1:
                        messagebox.showwarning(title="Mauvaise réponse", message="Ce n'est pas la bonne réponse!\nIl reste 1 essai!")
                        essaie = 0
                    elif essaie == 0:
                        messagebox.showwarning(title="Mauvaise réponse", message=f"Ce n'est pas la bonne réponse!\nLa bonne réponse était la case: {rep}!")
                        essaie = 2
                        lecture.QCM.test()
    class modifier:
        def main():
            titre.config(text="Modifiez un quiz")
            aide.config(text="Vous allez pouvoir continuez ou modifiez votre quiz")
            desc.config(text="Cependant, nous devons d'abord savoir quel type de quiz voulez-vous importez!\nVous devez également posséder les fichiers du quiz (crée ou reçu par une autre personne).")
            bouton1.config(text="Importer un quiz normale", command=modifier.quiz.load_main)
            bouton2.config(text="Importer un QCM", command=modifier.QCM.load_main)
            bouton3.destroy()
        class quiz:
            def load_main():
                titre.config(text="Ouvrir un questionnaire")
                aide.config(text="Nous devons tout d'abords importez le quiz!")
                desc.config(text="Pour cela, appuyer sur le bouton \"Importer\"\nSi finalement vous voulez faire autre chose! Vous pouvez arrêter le logiciel en appuyant sur \"Annuler\"")
                bouton1.config(text="Importer", command=modifier.quiz.load_question)
                bouton2.config(text="Annuler", command = option.quit)
            def load_question():
                global quest, soluc, nb_quest, suite, page
                suite = True
                page = 0
                fichier = askopenfilename(filetypes=[("Fichier question", "*.qst")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                    suite = False
                with open (fichier, 'r') as fichie:
                    quest = fichie.read().splitlines()
                if quest[0] != "simple":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour des questions simple")
                fichier = askopenfilename(filetypes=[("Fichier réponse quiz", "*.rps")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                with open (fichier, 'r') as fichie:
                    soluc = fichie.read().splitlines()
                if soluc[0] != "simple":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour des questions simple")
                    suite = False
                if suite == True:
                    nb_quest = int(len(quest)) - 1
                    del soluc[0], quest[0]
                    print(nb_quest)
                    print(quest)
                    création.question.rafraichir()
        class QCM:
            def load_main():
                titre.config(text="Ouvrir un QCM")
                aide.config(text="Nous devons tout d'abords importez le QCM!")
                desc.config(text="Pour cela, appuyer sur le bouton \"Importer\"\nSi finalement vous voulez faire autre chose! Vous pouvez arrêter le logiciel en appuyant sur \"Annuler\"")
                bouton1.config(text="Importer", command = modifier.QCM.load_question)
                bouton2.config(text="Annuler", command = option.quit)  
            def load_question():
                global quest, soluc, nb_quest, suite
                suite = True
                fichier = askopenfilename(filetypes=[("Fichier question", "*.qsm")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                    suite = False
                with open (fichier, 'r') as fichie:
                    quest = fichie.read().splitlines()
                if quest[0] != "QCM":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour les QCM")
                fichier = askopenfilename(filetypes=[("Fichier réponse quiz", "*.rpq")])
                if fichier == "":
                    messagebox.showerror(title="Aucun fichier choisie", message="Vous n'avez pas choisie de fichier lorsque cela l'a été demandé!")
                with open (fichier, 'r') as fichie:
                    soluc = fichie.read().splitlines()
                if soluc[0] != "QCM":
                    messagebox.showerror(title="Mauvais fichier!", message="Votre fichier n'est pas un fichier valide pour les QCM")
                    suite = False
                if suite == True:
                    nb_quest = int(len(quest)) - 1
                    print(nb_quest)
                    print(quest)
                    print(soluc)
                    del quest[0]
                    création.QCM.question()
    option.défintion() 
    option.main()
    consol("Fenêtre crée")
    print(sys.exc_info())
    root.mainloop()
except Exception as error:
    messagebox.showerror(title="Erreur fatale", message=f"Une erreur innatendu est survenue!\n{error}")
    crash = crash + [error]
    try:
        with open("crash.txt", 'w') as fichier:
            for crash in crash:
                fichier.write(f'{crash}\n')
    except PermissionError:
        messagebox.showerror(titre="Echec de l'écriture du rapport", message="Une erreur est survenue lors de l'écriture du rapport")
        sys.exit()
    messagebox.showinfo(title="Rapport écrit!", message="Rapport écrit dans \"crash.txt\"")
